Thanks for purchasing from us - Special Edition #V2.0 Beta, really appreciate it! [https://Discord.gg/sgx]
It is important to us that you maintain the security of the files as much as possible and that you don't give access to programmers that you don't trust! 
In the end it's your money, we're just warning you about this.

Store - https://patreon.com/NCHub
Our discord - Discord.gg/sgx
Youtube - https://www.youtube.com/@sgxcore

If you have a problem, errors, or anything else we can help you with, we're here for you.
If you didn't purchase the files together with the installation and you encountered something, we will be happy to help you as well.

Thank you again for the purchase, good luck! ♥
Don't forget - https://Discord.gg/sgx will be always for you!